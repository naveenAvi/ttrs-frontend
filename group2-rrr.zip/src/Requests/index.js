import axios from 'axios'
export const getStationList = () => {
    /*should send the current tab selected*/
    return  axios.post('http://127.0.0.1:8000/get-station-list', {  })  
}

export const addAStation = (formvals, track) => {
    /*should send the current tab selected*/
    return  axios.post('http://127.0.0.1:8000/add-a-station',{ formvals, track })  
}

export const getTrainsList = () => {
    /*should send the current tab selected*/
    return  axios.post('http://127.0.0.1:8000/get-trains-list',)  
}