export const FairsConstants = {
    SET_STATIONS_LIST: "SET_STATIONS_LIST",
    ADD_NEW_STATION: "ADD_NEW_STATION",
    ADD_NEW_STATION_OBJ:"ADD_NEW_STATION_OBJ"
}

export const TrainsListConstants = {
    SET_TRAIN_LIST: "SET_TRAIN_LIST",
}
