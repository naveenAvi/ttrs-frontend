import {  TrainsListConstants } from "../Constan"

export const set_trains_list = ( trainsList ) =>{
    return {
        type: TrainsListConstants.SET_TRAIN_LIST,
        payload: {
            trainsList 
        }
    }
}
