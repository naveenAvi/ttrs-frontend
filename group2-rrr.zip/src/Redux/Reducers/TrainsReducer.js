import {  TrainsListConstants } from "../Constan"


const initialState = []
const TrainsReducer = (state = initialState, { type, payload }) => {
    switch (type) {
        case TrainsListConstants.SET_TRAIN_LIST:
            return payload.trainsList;
        default:
            return state
    }
}

export default TrainsReducer